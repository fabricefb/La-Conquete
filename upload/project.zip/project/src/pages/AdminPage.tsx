import { useState, useEffect } from 'react';
import { SiteHeader } from '../components/SiteHeader';
import { MobileNav } from '../components/MobileNav';
import { InteractiveMap } from '../components/InteractiveMap';
import { supabase, type Location } from '../lib/supabase';
import { Plus, Trash2, Save, ArrowLeft, MapPin, Star, X, Edit3 } from '../lib/icons';
import type { Page } from '../lib/navigation';
import type { Theme } from '../lib/theme';

interface AdminPageProps { onNavigate: (page: Page) => void; theme: Theme; onToggleTheme: () => void; }

interface LocationForm {
  name: string;
  address: string;
  city: string;
  country: string;
  latitude: string;
  longitude: string;
  phone: string;
  email: string;
  service_times: string;
  pastor_name: string;
  is_main: boolean;
  is_active: boolean;
  sort_order: string;
}

const emptyForm: LocationForm = {
  name: '',
  address: '',
  city: '',
  country: 'RDC',
  latitude: '',
  longitude: '',
  phone: '',
  email: '',
  service_times: '',
  pastor_name: '',
  is_main: false,
  is_active: true,
  sort_order: '0',
};

export function AdminPage({ onNavigate, theme, onToggleTheme }: AdminPageProps) {
  const [locations, setLocations] = useState<Location[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<LocationForm>(emptyForm);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function fetchLocations() {
    setLoading(true);
    const { data, error: err } = await supabase.from('locations').select('*').order('sort_order');
    if (!err && data) setLocations(data);
    setLoading(false);
  }

  useEffect(() => { fetchLocations(); }, []);

  function openAdd() {
    setEditingId(null);
    setForm(emptyForm);
    setError(null);
    setShowForm(true);
  }

  function openEdit(loc: Location) {
    setEditingId(loc.id);
    setForm({
      name: loc.name,
      address: loc.address,
      city: loc.city,
      country: loc.country,
      latitude: String(loc.latitude),
      longitude: String(loc.longitude),
      phone: loc.phone ?? '',
      email: loc.email ?? '',
      service_times: loc.service_times ?? '',
      pastor_name: loc.pastor_name ?? '',
      is_main: loc.is_main,
      is_active: loc.is_active,
      sort_order: String(loc.sort_order),
    });
    setError(null);
    setShowForm(true);
  }

  function closeForm() {
    setShowForm(false);
    setEditingId(null);
    setForm(emptyForm);
    setError(null);
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);

    const payload = {
      name: form.name,
      address: form.address,
      city: form.city,
      country: form.country,
      latitude: parseFloat(form.latitude),
      longitude: parseFloat(form.longitude),
      phone: form.phone || null,
      email: form.email || null,
      service_times: form.service_times || null,
      pastor_name: form.pastor_name || null,
      is_main: form.is_main,
      is_active: form.is_active,
      sort_order: parseInt(form.sort_order, 10) || 0,
    };

    try {
      // If setting as main, reset all others first
      if (form.is_main) {
        await supabase.from('locations').update({ is_main: false }).neq('id', editingId ?? '');
      }

      if (editingId) {
        const { error: err } = await supabase.from('locations').update(payload).eq('id', editingId);
        if (err) throw err;
      } else {
        const { error: err } = await supabase.from('locations').insert(payload);
        if (err) throw err;
      }

      await fetchLocations();
      closeForm();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Une erreur est survenue.';
      setError(msg);
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id: string, name: string) {
    if (!confirm(`Supprimer "${name}" ?`)) return;
    await supabase.from('locations').delete().eq('id', id);
    await fetchLocations();
  }

  const f = (field: keyof LocationForm) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((p) => ({ ...p, [field]: e.target.type === 'checkbox' ? e.target.checked : e.target.value }));

  return (
    <div className="min-h-screen bg-bg text-cream">
      <SiteHeader onNavigate={onNavigate} activePage="admin" theme={theme} onToggleTheme={onToggleTheme} />

      <div className="mx-auto max-w-7xl px-4 pb-24 pt-24 sm:px-6 lg:px-8">

        {/* ─── PAGE HEADER ─── */}
        <div className="mb-10 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <button
              onClick={() => onNavigate('home')}
              className="mb-2 flex items-center gap-1.5 text-sm text-muted hover:text-cream transition-colors"
            >
              <ArrowLeft className="h-4 w-4" />
              Retour au site
            </button>
            <h1 className="font-serif text-4xl font-semibold text-cream">Administration</h1>
            <p className="mt-1 text-muted">Gestion des lieux de culte</p>
          </div>
          <button onClick={openAdd} className="btn-gold shrink-0">
            <Plus className="h-4 w-4" />
            Ajouter un lieu
          </button>
        </div>

        {/* ─── FORM ─── */}
        {showForm && (
          <div className="mb-10 glass rounded-4xl p-8 bg-radial-gold">
            <div className="mb-6 flex items-center justify-between">
              <h2 className="font-serif text-2xl font-semibold text-cream">
                {editingId ? 'Modifier le lieu' : 'Nouveau lieu'}
              </h2>
              <button onClick={closeForm} className="flex h-9 w-9 items-center justify-center rounded-full border border-line text-muted hover:text-cream transition-colors">
                <X className="h-4 w-4" />
              </button>
            </div>

            {error && (
              <div className="mb-5 rounded-2xl border border-ember-500/30 bg-ember-500/10 px-5 py-3 text-sm text-ember-400">
                {error}
              </div>
            )}

            <form onSubmit={handleSave} className="grid gap-4 sm:grid-cols-2">
              {/* Name */}
              <div className="sm:col-span-2">
                <label className="mb-1.5 block text-xs font-medium text-muted">Nom *</label>
                <input type="text" required value={form.name} onChange={f('name')} placeholder="Église principale" className="input-surface w-full px-4 py-3 text-sm" />
              </div>
              {/* Address */}
              <div className="sm:col-span-2">
                <label className="mb-1.5 block text-xs font-medium text-muted">Adresse *</label>
                <input type="text" required value={form.address} onChange={f('address')} placeholder="Av. Kabambare" className="input-surface w-full px-4 py-3 text-sm" />
              </div>
              {/* City */}
              <div>
                <label className="mb-1.5 block text-xs font-medium text-muted">Ville *</label>
                <input type="text" required value={form.city} onChange={f('city')} placeholder="Lubumbashi" className="input-surface w-full px-4 py-3 text-sm" />
              </div>
              {/* Country */}
              <div>
                <label className="mb-1.5 block text-xs font-medium text-muted">Pays</label>
                <input type="text" value={form.country} onChange={f('country')} placeholder="RDC" className="input-surface w-full px-4 py-3 text-sm" />
              </div>
              {/* Latitude */}
              <div>
                <label className="mb-1.5 block text-xs font-medium text-muted">Latitude *</label>
                <input type="number" step="any" required value={form.latitude} onChange={f('latitude')} placeholder="-11.6635" className="input-surface w-full px-4 py-3 text-sm" />
              </div>
              {/* Longitude */}
              <div>
                <label className="mb-1.5 block text-xs font-medium text-muted">Longitude *</label>
                <input type="number" step="any" required value={form.longitude} onChange={f('longitude')} placeholder="27.4794" className="input-surface w-full px-4 py-3 text-sm" />
              </div>
              {/* Phone */}
              <div>
                <label className="mb-1.5 block text-xs font-medium text-muted">Téléphone</label>
                <input type="tel" value={form.phone} onChange={f('phone')} placeholder="+243 844 107 079" className="input-surface w-full px-4 py-3 text-sm" />
              </div>
              {/* Email */}
              <div>
                <label className="mb-1.5 block text-xs font-medium text-muted">Email</label>
                <input type="email" value={form.email} onChange={f('email')} placeholder="contact@laconquete.cd" className="input-surface w-full px-4 py-3 text-sm" />
              </div>
              {/* Service times */}
              <div>
                <label className="mb-1.5 block text-xs font-medium text-muted">Horaires des cultes</label>
                <input type="text" value={form.service_times} onChange={f('service_times')} placeholder="Dim 10h, Ven 22h" className="input-surface w-full px-4 py-3 text-sm" />
              </div>
              {/* Pastor */}
              <div>
                <label className="mb-1.5 block text-xs font-medium text-muted">Pasteur responsable</label>
                <input type="text" value={form.pastor_name} onChange={f('pastor_name')} placeholder="Pasteur Kongolo" className="input-surface w-full px-4 py-3 text-sm" />
              </div>
              {/* Sort order */}
              <div>
                <label className="mb-1.5 block text-xs font-medium text-muted">Ordre d'affichage</label>
                <input type="number" value={form.sort_order} onChange={f('sort_order')} placeholder="0" className="input-surface w-full px-4 py-3 text-sm" />
              </div>
              {/* Checkboxes */}
              <div className="flex items-center gap-6 sm:col-span-2">
                <label className="flex cursor-pointer items-center gap-2.5 text-sm text-cream">
                  <input
                    type="checkbox"
                    checked={form.is_main}
                    onChange={(e) => setForm((p) => ({ ...p, is_main: e.target.checked }))}
                    className="h-4 w-4 rounded accent-gold-400"
                  />
                  Lieu principal
                </label>
                <label className="flex cursor-pointer items-center gap-2.5 text-sm text-cream">
                  <input
                    type="checkbox"
                    checked={form.is_active}
                    onChange={(e) => setForm((p) => ({ ...p, is_active: e.target.checked }))}
                    className="h-4 w-4 rounded accent-gold-400"
                  />
                  Actif
                </label>
              </div>
              {/* Actions */}
              <div className="flex items-center gap-3 sm:col-span-2">
                <button type="submit" disabled={saving} className="btn-gold">
                  {saving ? (
                    <span className="h-4 w-4 animate-spin rounded-full border-2 border-black/30 border-t-black" />
                  ) : (
                    <Save className="h-4 w-4" />
                  )}
                  {saving ? 'Enregistrement…' : 'Enregistrer'}
                </button>
                <button type="button" onClick={closeForm} className="btn-ghost">
                  Annuler
                </button>
              </div>
            </form>
          </div>
        )}

        {/* ─── LOCATION LIST ─── */}
        <div className="mb-12">
          <h2 className="mb-5 font-serif text-2xl font-semibold text-cream">
            Lieux ({locations.length})
          </h2>

          {loading ? (
            <div className="flex flex-col gap-4">
              {Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="glass rounded-2xl h-20 animate-pulse" />
              ))}
            </div>
          ) : locations.length === 0 ? (
            <div className="rounded-2xl border border-line p-10 text-center text-muted">
              <MapPin className="mx-auto mb-3 h-8 w-8 opacity-40" />
              <p>Aucun lieu enregistré.</p>
            </div>
          ) : (
            <div className="flex flex-col gap-4">
              {locations.map((loc) => (
                <div key={loc.id} className="glass rounded-2xl p-5 flex items-start justify-between gap-4 transition-all duration-200 hover:scale-[1.005]">
                  <div className="flex items-start gap-3">
                    <Star className={`mt-0.5 h-5 w-5 shrink-0 ${loc.is_main ? 'text-gold-400' : 'text-ember-400'}`} />
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="font-semibold text-cream">{loc.name}</p>
                        {loc.is_main && (
                          <span className="rounded-full bg-gold-400/20 px-2 py-0.5 text-[10px] font-bold uppercase tracking-widest text-gold-400">
                            Principal
                          </span>
                        )}
                        {!loc.is_active && (
                          <span className="rounded-full bg-white/10 px-2 py-0.5 text-[10px] font-bold uppercase tracking-widest text-muted">
                            Inactif
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-muted">{loc.address}, {loc.city}</p>
                      <p className="mt-0.5 text-xs text-muted/60">
                        GPS: {loc.latitude}, {loc.longitude}
                      </p>
                    </div>
                  </div>
                  <div className="flex shrink-0 items-center gap-2">
                    <button
                      onClick={() => openEdit(loc)}
                      className="flex h-9 w-9 items-center justify-center rounded-xl border border-line text-muted transition-all duration-200 hover:border-gold-400/40 hover:text-gold-400"
                    >
                      <Edit3 className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => handleDelete(loc.id, loc.name)}
                      className="flex h-9 w-9 items-center justify-center rounded-xl border border-line text-muted transition-all duration-200 hover:border-ember-500/40 hover:text-ember-400"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* ─── MAP ─── */}
        {locations.length > 0 && (
          <div>
            <h2 className="mb-5 font-serif text-2xl font-semibold text-cream">Carte des lieux</h2>
            <div className="grid lg:grid-cols-3">
              <div className="lg:col-span-2">
                <InteractiveMap locations={locations} className="h-[500px]" />
              </div>
            </div>
          </div>
        )}
      </div>

      <MobileNav onNavigate={onNavigate} active="admin" theme={theme} onToggleTheme={onToggleTheme} />
    </div>
  );
}
