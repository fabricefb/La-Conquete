import { useReveal, useParallax } from '../lib/hooks';
import { SiteHeader } from '../components/SiteHeader';
import { SiteFooter } from '../components/SiteFooter';
import { MobileNav } from '../components/MobileNav';
import { Radio, Sparkles, Crown, Flame, Compass, BookOpen, Calendar, Users, Quote, MapPin, Phone, Mail, ArrowRight } from '../lib/icons';
import type { Page } from '../lib/navigation';
import type { Theme } from '../lib/theme';

const HERO = 'https://images.pexels.com/photos/2889440/pexels-photo-2889440.jpeg?auto=compress&cs=tinysrgb&w=1920';
const CHURCH = 'https://images.pexels.com/photos/290468/pexels-photo-290468.jpeg?auto=compress&cs=tinysrgb&w=1200';
const PEOPLE = 'https://images.pexels.com/photos/8465180/pexels-photo-8465180.jpeg?auto=compress&cs=tinysrgb&w=800';
const SERMON = 'https://images.pexels.com/photos/261763/pexels-photo-261763.jpeg?auto=compress&cs=tinysrgb&w=800';
const EVENT = 'https://images.pexels.com/photos/2774557/pexels-photo-2774557.jpeg?auto=compress&cs=tinysrgb&w=800';

interface HomePageProps { onNavigate: (page: Page) => void; theme: Theme; onToggleTheme: () => void; }

const pillars = [
  { label: 'Bâtir', desc: 'Construire des fondations solides ancrées dans la Parole de Dieu.', Icon: Crown, accent: 'text-gold-400', radial: 'bg-radial-gold' },
  { label: 'Transformer', desc: 'Vivre une transformation intérieure par la puissance du Saint-Esprit.', Icon: Flame, accent: 'text-ember-400', radial: 'bg-radial-ember' },
  { label: 'Conquérir', desc: 'Avancer dans notre mission divine pour impacter des nations.', Icon: Compass, accent: 'text-gold-400', radial: 'bg-radial-gold' },
];

const exploreCards = [
  { img: SERMON, tag: 'Ressources', title: 'Derniers Sermons', Icon: BookOpen, page: 'media' as Page },
  { img: EVENT, tag: 'Calendrier', title: 'Événements & Agenda', Icon: Calendar, page: 'events' as Page },
  { img: PEOPLE, tag: 'Communauté', title: 'Nos Ministères', Icon: Users, page: 'activities' as Page },
];

const contactInfo = [
  { Icon: MapPin, label: 'Adresse', value: 'Av. Kabambare, Lubumbashi, RDC' },
  { Icon: Phone, label: 'Téléphone', value: '+243 844 107 079' },
  { Icon: Mail, label: 'Email', value: 'contact@laconquete.cd' },
];

function RevealSection({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  const { ref, visible } = useReveal();
  return (
    <div ref={ref} className={`reveal ${visible ? 'in' : ''} ${className}`}>
      {children}
    </div>
  );
}

export function HomePage({ onNavigate, theme, onToggleTheme }: HomePageProps) {
  const parallaxRef = useParallax<HTMLDivElement>(0.25);

  return (
    <div className="min-h-screen bg-bg text-cream">
      <SiteHeader onNavigate={onNavigate} activePage="home" theme={theme} onToggleTheme={onToggleTheme} />

      {/* ─── HERO ─── */}
      <section className="relative flex min-h-screen items-center justify-center overflow-hidden">
        <div ref={parallaxRef} className="absolute inset-0 will-change-transform">
          <img src={HERO} alt="Église La Conquête" className="h-full w-full object-cover" />
        </div>
        <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/50 to-bg" />

        <div className="relative z-10 mx-auto max-w-4xl px-4 pt-24 pb-16 text-center">
          <div className="animate-fade-up mb-6 flex justify-center">
            <span className="inline-flex items-center gap-2 rounded-full border border-gold-400/30 bg-gold-400/10 px-4 py-1.5 text-xs font-semibold uppercase tracking-widest text-gold-300">
              <Sparkles className="h-3.5 w-3.5" />
              Église Évangélique
            </span>
          </div>

          <h1 className="animate-fade-up mb-6 font-serif text-5xl font-semibold leading-tight tracking-tight sm:text-6xl lg:text-7xl" style={{ animationDelay: '0.1s' }}>
            Bâtir, Transformer<br />
            et{' '}
            <span className="gold-text">Conquérir</span>
          </h1>

          <p className="animate-fade-up mx-auto mb-10 max-w-xl text-lg text-muted leading-relaxed" style={{ animationDelay: '0.2s' }}>
            Impactez votre génération, transformez votre communauté et conquérez votre destinée avec la puissance de Dieu.
          </p>

          <div className="animate-fade-up flex flex-col items-center justify-center gap-4 sm:flex-row" style={{ animationDelay: '0.3s' }}>
            <button onClick={() => onNavigate('media')} className="btn-gold">
              <Radio className="h-4 w-4" />
              Suivre le Direct
            </button>
            <button onClick={() => onNavigate('contact')} className="btn-ghost">
              Planifier une visite
            </button>
          </div>

          {/* Scroll indicator */}
          <div className="animate-fade-up absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2" style={{ animationDelay: '0.8s' }}>
            <span className="text-[10px] font-semibold uppercase tracking-widest text-muted/60">Défiler</span>
            <div className="h-12 w-px bg-gradient-to-b from-gold-400/60 to-transparent" />
          </div>
        </div>
      </section>

      {/* ─── PILLARS ─── */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <RevealSection className="mb-14 text-center">
            <p className="section-label justify-center">Notre vision</p>
            <h2 className="mt-4 font-serif text-4xl font-semibold text-cream">Les trois piliers</h2>
          </RevealSection>

          <div className="grid gap-6 md:grid-cols-3">
            {pillars.map(({ label, desc, Icon, accent, radial }, i) => (
              <RevealSection key={label} className={`reveal-delay-${i + 1}`}>
                <div className={`glass rounded-3xl p-8 ${radial} group transition-all duration-300 hover:scale-105 hover:shadow-xl`}>
                  <div className={`mb-5 inline-flex h-12 w-12 items-center justify-center rounded-2xl border border-line ${accent}`}>
                    <Icon className="h-6 w-6" />
                  </div>
                  <h3 className={`mb-3 font-serif text-2xl font-semibold ${accent}`}>{label}</h3>
                  <p className="text-sm leading-relaxed text-muted">{desc}</p>
                </div>
              </RevealSection>
            ))}
          </div>
        </div>
      </section>

      {/* ─── VISION SPLIT ─── */}
      <section className="py-24 bg-radial-gold">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid items-center gap-16 lg:grid-cols-2">
            <RevealSection>
              <div className="overflow-hidden rounded-5xl">
                <img src={CHURCH} alt="Église" className="h-[480px] w-full object-cover transition-transform duration-700 hover:scale-105" />
              </div>
            </RevealSection>
            <RevealSection className="reveal-delay-1">
              <p className="section-label">Notre mission</p>
              <h2 className="mt-4 font-serif text-4xl font-semibold leading-snug text-cream">
                Conquérir des âmes<br />pour le Royaume de Dieu
              </h2>
              <p className="mt-6 text-muted leading-relaxed">
                Fondée sur la Parole vivante de Dieu, l'Église La Conquête est une communauté de foi qui croit en la puissance transformatrice de l'Évangile. Nous sommes appelés à bâtir des vies, à transformer des cœurs et à conquérir des nations pour la gloire de Dieu.
              </p>
              <p className="mt-4 text-muted leading-relaxed">
                Chaque croyant est un ambassadeur, porteur d'une vision divine pour sa génération. Ensemble, nous avançons dans notre destinée collective avec foi, amour et détermination.
              </p>
              <blockquote className="mt-8 border-l-2 border-gold-400/40 pl-5 text-sm italic text-muted">
                « Demande-moi, et je te donnerai les nations pour héritage. »
                <span className="mt-1 block not-italic font-semibold text-gold-400">— Psaumes 2:8</span>
              </blockquote>
              <button onClick={() => onNavigate('about')} className="btn-gold mt-8">
                En savoir plus
                <ArrowRight className="h-4 w-4" />
              </button>
            </RevealSection>
          </div>
        </div>
      </section>

      {/* ─── EXPLORE ─── */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <RevealSection className="mb-14 text-center">
            <p className="section-label justify-center">Explorer</p>
            <h2 className="mt-4 font-serif text-4xl font-semibold text-cream">Découvrez notre monde</h2>
          </RevealSection>

          <div className="grid gap-6 md:grid-cols-3">
            {exploreCards.map(({ img, tag, title, Icon, page }, i) => (
              <RevealSection key={title} className={`reveal-delay-${i + 1}`}>
                <button
                  onClick={() => onNavigate(page)}
                  className="group relative w-full overflow-hidden rounded-4xl text-left"
                >
                  <img src={img} alt={title} className="h-80 w-full object-cover transition-transform duration-700 group-hover:scale-110" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                  <div className="absolute bottom-0 left-0 right-0 p-6">
                    <span className="mb-2 inline-flex items-center gap-1.5 rounded-full border border-white/20 bg-white/10 px-3 py-1 text-[10px] font-semibold uppercase tracking-widest text-white/80">
                      {tag}
                    </span>
                    <h3 className="font-serif text-xl font-semibold text-white">{title}</h3>
                    <div className="mt-3 flex items-center gap-2 text-sm text-gold-300 opacity-0 transition-all duration-300 group-hover:opacity-100 group-hover:translate-x-1">
                      <Icon className="h-4 w-4" />
                      <span>Découvrir</span>
                    </div>
                  </div>
                </button>
              </RevealSection>
            ))}
          </div>
        </div>
      </section>

      {/* ─── QUOTE ─── */}
      <section className="py-24 bg-radial-gold">
        <div className="mx-auto max-w-3xl px-4 text-center sm:px-6 lg:px-8">
          <RevealSection>
            <div className="mb-6 flex justify-center">
              <Quote className="h-10 w-10 text-gold-400/50" />
            </div>
            <p className="font-serif text-2xl italic leading-relaxed text-cream sm:text-3xl">
              « Impactez votre génération, transformez votre communauté et conquérez votre destinée avec la puissance de Dieu. »
            </p>
            <p className="mt-6 font-semibold text-gold-400">— Matthieu 28:19</p>
          </RevealSection>
        </div>
      </section>

      {/* ─── CONTACT STRIP ─── */}
      <section className="py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <RevealSection className="mb-12 text-center">
            <p className="section-label justify-center">Nous rejoindre</p>
            <h2 className="mt-4 font-serif text-4xl font-semibold text-cream">Venez comme vous êtes</h2>
          </RevealSection>
          <div className="grid gap-6 sm:grid-cols-3">
            {contactInfo.map(({ Icon, label, value }) => (
              <RevealSection key={label}>
                <div className="glass rounded-3xl p-7 text-center transition-all duration-300 hover:scale-105">
                  <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-2xl border border-gold-400/20 text-gold-400">
                    <Icon className="h-5 w-5" />
                  </div>
                  <p className="mb-1 text-xs font-semibold uppercase tracking-widest text-muted">{label}</p>
                  <p className="text-sm font-medium text-cream">{value}</p>
                </div>
              </RevealSection>
            ))}
          </div>
        </div>
      </section>

      <SiteFooter onNavigate={onNavigate} theme={theme} onToggleTheme={onToggleTheme} />
      <MobileNav onNavigate={onNavigate} active="home" theme={theme} onToggleTheme={onToggleTheme} />
    </div>
  );
}
