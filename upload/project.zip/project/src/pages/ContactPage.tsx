import { useState, useEffect } from 'react';
import { useReveal } from '../lib/hooks';
import { SiteHeader } from '../components/SiteHeader';
import { SiteFooter } from '../components/SiteFooter';
import { MobileNav } from '../components/MobileNav';
import { InteractiveMap } from '../components/InteractiveMap';
import { supabase, type Location } from '../lib/supabase';
import { MapPin, Phone, Mail, Globe, Clock, Send, Navigation } from '../lib/icons';
import type { Page } from '../lib/navigation';
import type { Theme } from '../lib/theme';

interface ContactPageProps { onNavigate: (page: Page) => void; theme: Theme; onToggleTheme: () => void; }

const serviceTimes = [
  { day: 'Dimanche', service: 'Culte Principal', time: '10h00 – 13h00', Icon: Clock },
  { day: 'Mardi', service: 'Étude Biblique', time: '19h00 – 21h00', Icon: Clock },
  { day: 'Jeudi', service: 'Intercession', time: '18h30 – 20h30', Icon: Clock },
  { day: 'Vendredi', service: "Veillée d'Adoration", time: '22h00 – 02h00', Icon: Clock },
];

function RevealSection({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  const { ref, visible } = useReveal();
  return <div ref={ref} className={`reveal ${visible ? 'in' : ''} ${className}`}>{children}</div>;
}

export function ContactPage({ onNavigate, theme, onToggleTheme }: ContactPageProps) {
  const [locations, setLocations] = useState<Location[]>([]);
  const [selectedLocation, setSelectedLocation] = useState<Location | null>(null);
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: '' });
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);

  useEffect(() => {
    async function fetchLocations() {
      const { data } = await supabase.from('locations').select('*').eq('is_active', true).order('sort_order');
      if (data) {
        setLocations(data);
        const main = data.find((l: Location) => l.is_main);
        setSelectedLocation(main ?? data[0] ?? null);
      }
    }
    fetchLocations();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSending(true);
    await new Promise((r) => setTimeout(r, 1000));
    setSent(true);
    setSending(false);
    setForm({ name: '', email: '', subject: '', message: '' });
  };

  return (
    <div className="min-h-screen bg-bg text-cream">
      <SiteHeader onNavigate={onNavigate} activePage="contact" theme={theme} onToggleTheme={onToggleTheme} />

      {/* ─── HERO ─── */}
      <section className="relative flex min-h-[40vh] items-center justify-center overflow-hidden pt-16 bg-radial-gold">
        <div className="relative z-10 mx-auto max-w-3xl px-4 py-20 text-center">
          <RevealSection>
            <p className="section-label justify-center">Contact</p>
            <h1 className="mt-4 font-serif text-5xl font-semibold text-cream sm:text-6xl">Parlons-en</h1>
            <p className="mt-6 text-lg text-muted">
              Que vous ayez une question, un témoignage ou souhaitiez en savoir plus, nous sommes là pour vous.
            </p>
          </RevealSection>
        </div>
      </section>

      {/* ─── CONTACT FORM + INFO ─── */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-12 lg:grid-cols-5">

            {/* ─── LEFT: Info ─── */}
            <RevealSection className="lg:col-span-2">
              <div className="flex flex-col gap-6">
                <h2 className="font-serif text-3xl font-semibold text-cream">Nos coordonnées</h2>

                {/* Contact cards */}
                <div className="flex flex-col gap-4">
                  <div className="glass rounded-2xl p-5 flex items-start gap-4">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-gold-400/20 text-gold-400">
                      <MapPin className="h-4 w-4" />
                    </div>
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-widest text-muted">Adresse</p>
                      <p className="mt-1 text-sm text-cream">Av. Kabambare, Lubumbashi, RDC</p>
                    </div>
                  </div>
                  <div className="glass rounded-2xl p-5 flex items-start gap-4">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-gold-400/20 text-gold-400">
                      <Phone className="h-4 w-4" />
                    </div>
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-widest text-muted">Téléphone</p>
                      <a href="tel:+243844107079" className="mt-1 block text-sm text-cream hover:text-gold-400 transition-colors">
                        +243 844 107 079
                      </a>
                    </div>
                  </div>
                  <div className="glass rounded-2xl p-5 flex items-start gap-4">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-gold-400/20 text-gold-400">
                      <Mail className="h-4 w-4" />
                    </div>
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-widest text-muted">Email</p>
                      <a href="mailto:contact@laconquete.cd" className="mt-1 block text-sm text-cream hover:text-gold-400 transition-colors">
                        contact@laconquete.cd
                      </a>
                    </div>
                  </div>
                </div>

                {/* Social links */}
                <div>
                  <p className="mb-3 text-xs font-semibold uppercase tracking-widest text-muted">Réseaux sociaux</p>
                  <div className="flex items-center gap-3">
                    {[
                      { label: 'Facebook', href: 'https://facebook.com' },
                      { label: 'YouTube', href: 'https://youtube.com' },
                      { label: 'WhatsApp', href: 'https://wa.me/243844107079' },
                    ].map(({ label, href }) => (
                      <a
                        key={label}
                        href={href}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-1.5 rounded-full border border-line px-4 py-1.5 text-xs font-medium text-muted transition-all duration-200 hover:border-gold-400/40 hover:text-gold-400"
                      >
                        <Globe className="h-3.5 w-3.5" />
                        {label}
                      </a>
                    ))}
                  </div>
                </div>
              </div>
            </RevealSection>

            {/* ─── RIGHT: Form ─── */}
            <RevealSection className="lg:col-span-3 reveal-delay-1">
              <div className="glass rounded-4xl p-8">
                <h2 className="mb-6 font-serif text-2xl font-semibold text-cream">Envoyez-nous un message</h2>

                {sent ? (
                  <div className="py-12 text-center">
                    <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-3xl bg-gold-400/20 text-gold-400">
                      <Send className="h-7 w-7" />
                    </div>
                    <h3 className="font-serif text-2xl font-semibold text-cream">Message envoyé !</h3>
                    <p className="mt-2 text-muted">Nous vous répondrons dans les plus brefs délais.</p>
                    <button onClick={() => setSent(false)} className="btn-ghost mt-6 text-sm px-5 py-2.5">
                      Envoyer un autre message
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="flex flex-col gap-4">
                    <div className="grid gap-4 sm:grid-cols-2">
                      <div>
                        <label className="mb-1.5 block text-xs font-medium text-muted">Nom complet *</label>
                        <input
                          type="text"
                          required
                          value={form.name}
                          onChange={(e) => setForm((p) => ({ ...p, name: e.target.value }))}
                          placeholder="Jean Dupont"
                          className="input-surface w-full px-4 py-3 text-sm"
                        />
                      </div>
                      <div>
                        <label className="mb-1.5 block text-xs font-medium text-muted">Adresse email *</label>
                        <input
                          type="email"
                          required
                          value={form.email}
                          onChange={(e) => setForm((p) => ({ ...p, email: e.target.value }))}
                          placeholder="vous@email.com"
                          className="input-surface w-full px-4 py-3 text-sm"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="mb-1.5 block text-xs font-medium text-muted">Sujet</label>
                      <input
                        type="text"
                        value={form.subject}
                        onChange={(e) => setForm((p) => ({ ...p, subject: e.target.value }))}
                        placeholder="Comment pouvons-nous vous aider ?"
                        className="input-surface w-full px-4 py-3 text-sm"
                      />
                    </div>
                    <div>
                      <label className="mb-1.5 block text-xs font-medium text-muted">Message *</label>
                      <textarea
                        required
                        rows={5}
                        value={form.message}
                        onChange={(e) => setForm((p) => ({ ...p, message: e.target.value }))}
                        placeholder="Votre message…"
                        className="input-surface w-full resize-none px-4 py-3 text-sm"
                      />
                    </div>
                    <button type="submit" disabled={sending} className="btn-gold self-start">
                      {sending ? (
                        <span className="h-4 w-4 animate-spin rounded-full border-2 border-black/30 border-t-black" />
                      ) : (
                        <Send className="h-4 w-4" />
                      )}
                      {sending ? 'Envoi…' : 'Envoyer'}
                    </button>
                  </form>
                )}
              </div>
            </RevealSection>
          </div>
        </div>
      </section>

      {/* ─── SERVICE TIMES ─── */}
      <section className="py-24 bg-radial-gold">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <RevealSection className="mb-12 text-center">
            <p className="section-label justify-center">Horaires</p>
            <h2 className="mt-4 font-serif text-4xl font-semibold text-cream">Nos cultes</h2>
          </RevealSection>
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {serviceTimes.map(({ day, service, time, Icon }, i) => (
              <RevealSection key={day} className={`reveal-delay-${i + 1}`}>
                <div className="glass rounded-3xl p-6 text-center transition-all duration-300 hover:scale-105">
                  <div className="mx-auto mb-4 flex h-11 w-11 items-center justify-center rounded-2xl border border-gold-400/20 text-gold-400">
                    <Icon className="h-5 w-5" />
                  </div>
                  <p className="text-xs font-bold uppercase tracking-widest text-gold-400">{day}</p>
                  <h3 className="mt-1 font-serif text-lg font-semibold text-cream">{service}</h3>
                  <p className="mt-1 text-sm text-muted">{time}</p>
                </div>
              </RevealSection>
            ))}
          </div>
        </div>
      </section>

      {/* ─── MAP ─── */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <RevealSection className="mb-12 text-center">
            <p className="section-label justify-center">Nous trouver</p>
            <h2 className="mt-4 font-serif text-4xl font-semibold text-cream">Nos lieux de culte</h2>
          </RevealSection>

          {locations.length > 0 && (
            <div className="grid gap-8 lg:grid-cols-3">
              {/* Location list */}
              <RevealSection>
                <div className="flex flex-col gap-3">
                  {locations.map((loc) => (
                    <button
                      key={loc.id}
                      onClick={() => setSelectedLocation(loc)}
                      className={`glass rounded-2xl p-4 text-left transition-all duration-200 hover:scale-[1.01] ${
                        selectedLocation?.id === loc.id ? 'border-gold-400/40 bg-gold-400/5' : ''
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <MapPin className={`mt-0.5 h-4 w-4 shrink-0 ${loc.is_main ? 'text-gold-400' : 'text-ember-400'}`} />
                        <div>
                          <p className="text-sm font-semibold text-cream">{loc.name}</p>
                          <p className="mt-0.5 text-xs text-muted">{loc.address}, {loc.city}</p>
                          {loc.service_times && (
                            <p className="mt-1 text-xs text-muted/60">{loc.service_times}</p>
                          )}
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              </RevealSection>

              {/* Map */}
              <RevealSection className="lg:col-span-2 reveal-delay-1">
                <InteractiveMap
                  locations={locations}
                  onSelect={setSelectedLocation}
                  className="h-[400px] lg:h-[500px] overflow-hidden rounded-5xl glass"
                />
              </RevealSection>
            </div>
          )}

          {/* Selected location detail */}
          {selectedLocation && (
            <RevealSection className="mt-8">
              <div className="glass rounded-3xl p-6 flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                <div className="flex items-start gap-4">
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl border border-gold-400/20 text-gold-400">
                    <MapPin className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="font-serif text-lg font-semibold text-cream">{selectedLocation.name}</h3>
                    <p className="text-sm text-muted">{selectedLocation.address}, {selectedLocation.city}, {selectedLocation.country}</p>
                    {selectedLocation.pastor_name && (
                      <p className="mt-1 text-xs text-muted/70">Pasteur : {selectedLocation.pastor_name}</p>
                    )}
                    {selectedLocation.phone && (
                      <a href={`tel:${selectedLocation.phone}`} className="mt-1 flex items-center gap-1.5 text-xs text-muted hover:text-gold-400 transition-colors">
                        <Phone className="h-3 w-3" />
                        {selectedLocation.phone}
                      </a>
                    )}
                  </div>
                </div>
                <a
                  href={`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(`${selectedLocation.address}, ${selectedLocation.city}`)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-ghost text-sm px-5 py-2.5 shrink-0 flex items-center gap-2"
                >
                  <Navigation className="h-4 w-4" />
                  Itinéraire
                </a>
              </div>
            </RevealSection>
          )}
        </div>
      </section>

      <SiteFooter onNavigate={onNavigate} theme={theme} onToggleTheme={onToggleTheme} />
      <MobileNav onNavigate={onNavigate} active="contact" theme={theme} onToggleTheme={onToggleTheme} />
    </div>
  );
}
