import { createClient } from '@supabase/supabase-js';

export const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

export interface ChurchEvent {
  id: string; title: string; description: string; category: string;
  image_url: string; event_date: string; location: string;
  is_featured: boolean; is_live: boolean; created_at: string;
}

export interface Location {
  id: string; name: string; address: string; city: string; country: string;
  latitude: number; longitude: number; phone: string | null; email: string | null;
  service_times: string | null; pastor_name: string | null;
  is_main: boolean; is_active: boolean; sort_order: number;
  created_at: string; updated_at: string;
}
