import { useEffect, useState } from 'react';
import { HomePage } from './pages/HomePage';
import { AboutPage } from './pages/AboutPage';
import { ActivitiesPage } from './pages/ActivitiesPage';
import { EventsPage } from './pages/EventsPage';
import { MediaPage } from './pages/MediaPage';
import { ContactPage } from './pages/ContactPage';
import { AdminPage } from './pages/AdminPage';
import { useTheme } from './lib/theme';
import type { Page } from './lib/navigation';

const VALID_PAGES: Page[] = ['home','about','activities','events','media','contact','admin'];
function getPage(): Page { const h = window.location.hash.replace('#',''); return VALID_PAGES.includes(h as Page) ? (h as Page) : 'home'; }

function App() {
  const [page, setPage] = useState<Page>(getPage);
  const { theme, toggle } = useTheme();
  useEffect(() => { window.location.hash = page; }, [page]);
  useEffect(() => { const fn = () => setPage(getPage()); window.addEventListener('hashchange', fn); return () => window.removeEventListener('hashchange', fn); }, []);
  useEffect(() => { window.scrollTo(0, 0); }, [page]);
  const p = { onNavigate: setPage, theme, onToggleTheme: toggle };
  switch (page) {
    case 'home': return <HomePage {...p} />;
    case 'about': return <AboutPage {...p} />;
    case 'activities': return <ActivitiesPage {...p} />;
    case 'events': return <EventsPage {...p} />;
    case 'media': return <MediaPage {...p} />;
    case 'contact': return <ContactPage {...p} />;
    case 'admin': return <AdminPage {...p} />;
    default: return <HomePage {...p} />;
  }
}
export default App;
