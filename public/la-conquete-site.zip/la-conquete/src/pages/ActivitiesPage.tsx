import { useReveal } from '../lib/hooks';
import { SiteHeader } from '../components/SiteHeader';
import { SiteFooter } from '../components/SiteFooter';
import { MobileNav } from '../components/MobileNav';
import { Users, Heart, Crown, BookOpen, Moon, Flame, HandHeart, Sparkles } from '../lib/icons';
import type { Page } from '../lib/navigation';
import type { Theme } from '../lib/theme';

const PEOPLE = 'https://images.pexels.com/photos/8465180/pexels-photo-8465180.jpeg?auto=compress&cs=tinysrgb&w=800';

interface ActivitiesPageProps { onNavigate: (page: Page) => void; theme: Theme; onToggleTheme: () => void; }

const ministries = [
  {
    title: 'Jeunesse',
    desc: 'Un espace dynamique où les jeunes découvrent leur identité en Christ et développent leurs dons pour l'avenir.',
    schedule: 'Samedi à 15h00',
    Icon: Users,
    accent: 'text-gold-400',
    radial: 'bg-radial-gold',
  },
  {
    title: 'Femmes de Foi',
    desc: 'Un ministère dédié à fortifier les femmes dans leur foi, leur famille et leur vocation divine.',
    schedule: 'Mercredi à 17h00',
    Icon: Heart,
    accent: 'text-ember-400',
    radial: 'bg-radial-ember',
  },
  {
    title: 'Hommes de Valeur',
    desc: 'Former des hommes intègres, responsables et engagés dans leur famille, leur église et leur communauté.',
    schedule: 'Samedi à 08h00',
    Icon: Crown,
    accent: 'text-gold-400',
    radial: 'bg-radial-gold',
  },
  {
    title: 'Étude Biblique',
    desc: 'Des sessions d'approfondissement de la Parole de Dieu pour affermir votre foi et votre compréhension.',
    schedule: 'Mardi à 19h00',
    Icon: BookOpen,
    accent: 'text-ember-400',
    radial: 'bg-radial-ember',
  },
  {
    title: "Veillée d'Adoration",
    desc: 'Des nuits dédiées à l'adoration, la prière et la présence de Dieu pour des percées spirituelles.',
    schedule: 'Vendredi à 22h00',
    Icon: Moon,
    accent: 'text-gold-400',
    radial: 'bg-radial-gold',
  },
  {
    title: 'Missions',
    desc: 'Portez l'Évangile au-delà des frontières de notre église à travers des équipes missionnaires locales et internationales.',
    schedule: 'Mensuel',
    Icon: Flame,
    accent: 'text-ember-400',
    radial: 'bg-radial-ember',
  },
  {
    title: 'Intercession',
    desc: 'Rejoignez des guerriers de la prière qui intercèdent pour l'église, la nation et le monde entier.',
    schedule: 'Jeudi à 18h30',
    Icon: HandHeart,
    accent: 'text-gold-400',
    radial: 'bg-radial-gold',
  },
  {
    title: 'Louange',
    desc: 'Une équipe de musiciens et de chanteurs passionnés qui conduisent la congrégation dans un culte authentique.',
    schedule: 'Dimanche + répétitions',
    Icon: Sparkles,
    accent: 'text-ember-400',
    radial: 'bg-radial-ember',
  },
];

function RevealSection({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  const { ref, visible } = useReveal();
  return <div ref={ref} className={`reveal ${visible ? 'in' : ''} ${className}`}>{children}</div>;
}

export function ActivitiesPage({ onNavigate, theme, onToggleTheme }: ActivitiesPageProps) {
  return (
    <div className="min-h-screen bg-bg text-cream">
      <SiteHeader onNavigate={onNavigate} activePage="activities" theme={theme} onToggleTheme={onToggleTheme} />

      {/* ─── HERO ─── */}
      <section className="relative flex min-h-[50vh] items-center justify-center overflow-hidden pt-16 bg-radial-gold">
        <div className="relative z-10 mx-auto max-w-3xl px-4 py-24 text-center">
          <RevealSection>
            <p className="section-label justify-center">Communauté</p>
            <h1 className="mt-4 font-serif text-5xl font-semibold text-cream sm:text-6xl">Nos Activités</h1>
            <p className="mt-6 text-lg text-muted">
              Chaque ministère est un espace où vous pouvez grandir, servir et vous épanouir dans votre vocation.
            </p>
          </RevealSection>
        </div>
      </section>

      {/* ─── MINISTRIES GRID ─── */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <RevealSection className="mb-14 text-center">
            <p className="section-label justify-center">Nos ministères</p>
            <h2 className="mt-4 font-serif text-4xl font-semibold text-cream">Trouvez votre place</h2>
            <p className="mt-4 mx-auto max-w-xl text-muted">
              Quel que soit votre parcours ou vos dons, il y a une place pour vous au sein de nos ministères.
            </p>
          </RevealSection>

          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {ministries.map(({ title, desc, schedule, Icon, accent, radial }, i) => (
              <RevealSection key={title} className={`reveal-delay-${(i % 3) + 1}`}>
                <div className={`glass rounded-3xl p-7 ${radial} h-full flex flex-col transition-all duration-300 hover:scale-105 hover:shadow-xl`}>
                  <div className={`mb-4 inline-flex h-11 w-11 items-center justify-center rounded-2xl border border-line ${accent}`}>
                    <Icon className="h-5 w-5" />
                  </div>
                  <h3 className={`mb-2 font-serif text-xl font-semibold ${accent}`}>{title}</h3>
                  <p className="flex-1 text-sm text-muted leading-relaxed mb-4">{desc}</p>
                  <div className="flex items-center gap-2 text-xs font-medium text-muted border-t border-line pt-4">
                    <span className={`h-1.5 w-1.5 rounded-full ${accent.replace('text-', 'bg-')}`} />
                    {schedule}
                  </div>
                </div>
              </RevealSection>
            ))}
          </div>
        </div>
      </section>

      {/* ─── CTA BANNER ─── */}
      <section className="py-24 relative overflow-hidden">
        <div className="absolute inset-0">
          <img src={PEOPLE} alt="Communauté" className="h-full w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-r from-black/85 via-black/60 to-black/40" />
        </div>
        <div className="relative z-10 mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <RevealSection>
            <div className="max-w-xl">
              <p className="section-label">Rejoignez-nous</p>
              <h2 className="mt-4 font-serif text-4xl font-semibold text-white leading-snug">
                Impliquez-vous dans<br />notre communauté
              </h2>
              <p className="mt-6 text-white/70 leading-relaxed">
                Chaque personne a une contribution unique à apporter. Que vous soyez musicien, enseignant, intercesseur ou missionnaire, vos dons sont nécessaires ici.
              </p>
              <button onClick={() => onNavigate('contact')} className="btn-gold mt-8">
                Nous contacter
              </button>
            </div>
          </RevealSection>
        </div>
      </section>

      <SiteFooter onNavigate={onNavigate} theme={theme} onToggleTheme={onToggleTheme} />
      <MobileNav onNavigate={onNavigate} active="activities" theme={theme} onToggleTheme={onToggleTheme} />
    </div>
  );
}
