import { useState } from 'react';
import { useReveal } from '../lib/hooks';
import { SiteHeader } from '../components/SiteHeader';
import { SiteFooter } from '../components/SiteFooter';
import { MobileNav } from '../components/MobileNav';
import { Play, Radio, Search, BookOpen, Headphones, FileText, Star } from '../lib/icons';
import type { Page } from '../lib/navigation';
import type { Theme } from '../lib/theme';

const SERMON = 'https://images.pexels.com/photos/261763/pexels-photo-261763.jpeg?auto=compress&cs=tinysrgb&w=800';
const PEOPLE = 'https://images.pexels.com/photos/8465180/pexels-photo-8465180.jpeg?auto=compress&cs=tinysrgb&w=800';
const EVENT = 'https://images.pexels.com/photos/2774557/pexels-photo-2774557.jpeg?auto=compress&cs=tinysrgb&w=800';
const CHURCH = 'https://images.pexels.com/photos/290468/pexels-photo-290468.jpeg?auto=compress&cs=tinysrgb&w=800';

interface MediaPageProps { onNavigate: (page: Page) => void; theme: Theme; onToggleTheme: () => void; }

type TabType = 'sermons' | 'audio' | 'articles' | 'reading';

const TABS: { key: TabType; label: string; Icon: React.ElementType }[] = [
  { key: 'sermons', label: 'Sermons', Icon: Play },
  { key: 'audio', label: 'Audio', Icon: Headphones },
  { key: 'articles', label: 'Articles', Icon: FileText },
  { key: 'reading', label: 'Plans de lecture', Icon: BookOpen },
];

const sermons = [
  { title: 'La puissance de la foi conquérante', speaker: 'Past. Kongolo', duration: '52:14', date: '15 Jan 2025', live: true, img: SERMON },
  { title: 'Construire sur le roc inébranlable', speaker: 'Past. Kazadi', duration: '44:30', date: '8 Jan 2025', live: false, img: PEOPLE },
  { title: 'Transformer sa génération', speaker: 'Past. Kongolo', duration: '48:05', date: '1 Jan 2025', live: false, img: EVENT },
  { title: 'Les portes du ciel sont ouvertes', speaker: 'Past. Kazadi', duration: '39:22', date: '25 Déc 2024', live: false, img: CHURCH },
];

const audios = [
  { title: 'Intercession nationale', speaker: 'Équipe d'intercession', duration: '1h 12min', date: '20 Jan 2025' },
  { title: 'École du dimanche — Foi et œuvres', speaker: 'Past. Kongolo', duration: '38:44', date: '12 Jan 2025' },
  { title: 'Témoignage de guérison', speaker: 'Frère Emmanuel', duration: '22:10', date: '5 Jan 2025' },
  { title: 'Chants de louange — Veillée de Noël', speaker: 'Équipe de louange', duration: '1h 05min', date: '24 Déc 2024' },
];

const articles = [
  {
    title: 'Comment développer une vie de prière efficace',
    excerpt: 'La prière est le moteur de toute vie spirituelle fructueuse. Découvrez les principes fondamentaux pour une communion profonde avec Dieu.',
    readTime: '5 min',
    date: '18 Jan 2025',
    img: SERMON,
  },
  {
    title: 'Les clés d'une famille fondée sur Dieu',
    excerpt: 'La famille est le premier terrain de mission. Voici comment bâtir un foyer qui glorifie Dieu et rayonne dans votre entourage.',
    readTime: '7 min',
    date: '10 Jan 2025',
    img: PEOPLE,
  },
  {
    title: 'Comprendre votre identité en Christ',
    excerpt: 'Vous êtes enfant de Dieu, héritier de ses promesses. Explorez ce que cela signifie concrètement pour votre quotidien.',
    readTime: '6 min',
    date: '2 Jan 2025',
    img: CHURCH,
  },
];

const readingPlans = [
  { title: '30 Jours de Foi', desc: 'Un parcours quotidien pour affermir votre foi à travers les Écritures et des dévotions guidées.', days: 30, Icon: Star },
  { title: 'Psaumes de Conquête', desc: 'Plongez dans les psaumes guerriers et découvrez la puissance de la louange comme arme spirituelle.', days: 15, Icon: BookOpen },
  { title: 'Vie Transformée', desc: 'Un plan d'étude sur les Épîtres de Paul pour comprendre la transformation intérieure par le Saint-Esprit.', days: 21, Icon: Radio },
];

function RevealSection({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  const { ref, visible } = useReveal();
  return <div ref={ref} className={`reveal ${visible ? 'in' : ''} ${className}`}>{children}</div>;
}

export function MediaPage({ onNavigate, theme, onToggleTheme }: MediaPageProps) {
  const [activeTab, setActiveTab] = useState<TabType>('sermons');
  const [search, setSearch] = useState('');

  return (
    <div className="min-h-screen bg-bg text-cream">
      <SiteHeader onNavigate={onNavigate} activePage="media" theme={theme} onToggleTheme={onToggleTheme} />

      {/* ─── HERO ─── */}
      <section className="relative flex min-h-[40vh] items-center justify-center overflow-hidden pt-16 bg-radial-gold">
        <div className="relative z-10 mx-auto max-w-3xl px-4 py-20 text-center">
          <RevealSection>
            <p className="section-label justify-center">Médias</p>
            <h1 className="mt-4 font-serif text-5xl font-semibold text-cream sm:text-6xl">Ressources</h1>
            <p className="mt-6 text-lg text-muted">
              Sermons, enseignements, articles et plans de lecture pour nourrir votre foi.
            </p>
          </RevealSection>
        </div>
      </section>

      {/* ─── TABS + SEARCH ─── */}
      <section className="sticky top-16 z-30 border-b border-line bg-bg/90 backdrop-blur-xl">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col gap-4 py-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0">
              {TABS.map(({ key, label, Icon }) => (
                <button
                  key={key}
                  onClick={() => setActiveTab(key)}
                  className={`shrink-0 flex items-center gap-2 rounded-full px-4 py-1.5 text-sm font-medium transition-all duration-200 ${
                    activeTab === key
                      ? 'bg-gradient-to-r from-gold-300 to-gold-500 text-black'
                      : 'border border-line text-muted hover:border-gold-400/40 hover:text-cream'
                  }`}
                >
                  <Icon className="h-3.5 w-3.5" />
                  {label}
                </button>
              ))}
            </div>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted" />
              <input
                type="text"
                placeholder="Rechercher…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="input-surface w-full py-2 pl-9 pr-4 text-sm sm:w-56"
              />
            </div>
          </div>
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">

        {/* ─── SERMONS ─── */}
        {activeTab === 'sermons' && (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {sermons
              .filter((s) => !search || s.title.toLowerCase().includes(search.toLowerCase()))
              .map((sermon, i) => (
                <RevealSection key={sermon.title} className={`reveal-delay-${(i % 4) + 1}`}>
                  <div className="glass rounded-3xl overflow-hidden group transition-all duration-300 hover:scale-105">
                    <div className="relative h-48 overflow-hidden">
                      <img src={sermon.img} alt={sermon.title} className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110" />
                      <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                        <div className="flex h-14 w-14 items-center justify-center rounded-full bg-gold-400 text-black shadow-lg">
                          <Play className="h-6 w-6 ml-1" />
                        </div>
                      </div>
                      <div className="absolute bottom-2 right-2 rounded-lg bg-black/70 px-2 py-0.5 text-xs font-medium text-white">
                        {sermon.duration}
                      </div>
                      {sermon.live && (
                        <div className="absolute top-2 left-2 flex items-center gap-1 rounded-full bg-red-500 px-2 py-0.5 text-[10px] font-bold uppercase text-white">
                          <span className="h-1.5 w-1.5 rounded-full bg-white animate-pulse" />
                          Live
                        </div>
                      )}
                    </div>
                    <div className="p-5">
                      <h3 className="font-serif text-base font-semibold text-cream line-clamp-2">{sermon.title}</h3>
                      <p className="mt-1 text-xs text-muted">{sermon.speaker}</p>
                      <p className="mt-1 text-xs text-muted/60">{sermon.date}</p>
                    </div>
                  </div>
                </RevealSection>
              ))}
          </div>
        )}

        {/* ─── AUDIO ─── */}
        {activeTab === 'audio' && (
          <div className="flex flex-col gap-4 max-w-3xl mx-auto">
            {audios
              .filter((a) => !search || a.title.toLowerCase().includes(search.toLowerCase()))
              .map((audio, i) => (
                <RevealSection key={audio.title} className={`reveal-delay-${(i % 3) + 1}`}>
                  <div className="glass rounded-2xl p-5 flex items-center gap-5 transition-all duration-300 hover:scale-[1.01]">
                    <button className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-gold-300 to-gold-500 text-black shadow-md hover:brightness-110 transition-all">
                      <Play className="h-5 w-5 ml-0.5" />
                    </button>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-cream text-sm leading-snug line-clamp-1">{audio.title}</h3>
                      <p className="mt-0.5 text-xs text-muted">{audio.speaker}</p>
                    </div>
                    <div className="shrink-0 text-right">
                      <p className="text-xs font-medium text-gold-400">{audio.duration}</p>
                      <p className="text-xs text-muted/60">{audio.date}</p>
                    </div>
                  </div>
                </RevealSection>
              ))}
          </div>
        )}

        {/* ─── ARTICLES ─── */}
        {activeTab === 'articles' && (
          <div className="grid gap-6 sm:grid-cols-3">
            {articles
              .filter((a) => !search || a.title.toLowerCase().includes(search.toLowerCase()))
              .map((article, i) => (
                <RevealSection key={article.title} className={`reveal-delay-${i + 1}`}>
                  <div className="glass rounded-3xl overflow-hidden h-full flex flex-col transition-all duration-300 hover:scale-[1.02]">
                    <div className="relative h-48 overflow-hidden">
                      <img src={article.img} alt={article.title} className="h-full w-full object-cover transition-transform duration-700 hover:scale-110" />
                      <div className="absolute top-3 left-3 flex h-9 w-9 items-center justify-center rounded-xl bg-black/60 backdrop-blur-sm text-gold-400">
                        <FileText className="h-4 w-4" />
                      </div>
                    </div>
                    <div className="flex flex-col flex-1 p-5">
                      <h3 className="font-serif text-lg font-semibold text-cream">{article.title}</h3>
                      <p className="mt-2 flex-1 text-sm text-muted leading-relaxed line-clamp-3">{article.excerpt}</p>
                      <div className="mt-4 flex items-center justify-between text-xs text-muted/70">
                        <span>{article.date}</span>
                        <span className="text-gold-400 font-medium">{article.readTime} de lecture</span>
                      </div>
                    </div>
                  </div>
                </RevealSection>
              ))}
          </div>
        )}

        {/* ─── READING PLANS ─── */}
        {activeTab === 'reading' && (
          <div className="grid gap-6 sm:grid-cols-3 max-w-4xl mx-auto">
            {readingPlans.map(({ title, desc, days, Icon: PlanIcon }, i) => (
              <RevealSection key={title} className={`reveal-delay-${i + 1}`}>
                <div className="glass rounded-3xl p-7 bg-radial-gold h-full flex flex-col transition-all duration-300 hover:scale-105">
                  <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl border border-gold-400/20 text-gold-400">
                    <PlanIcon className="h-5 w-5" />
                  </div>
                  <h3 className="font-serif text-xl font-semibold text-cream">{title}</h3>
                  <p className="mt-3 flex-1 text-sm text-muted leading-relaxed">{desc}</p>
                  <div className="mt-5 flex items-center justify-between">
                    <span className="text-xs font-semibold text-gold-400">{days} jours</span>
                    <button className="btn-ghost text-xs px-4 py-2">Commencer</button>
                  </div>
                </div>
              </RevealSection>
            ))}
          </div>
        )}
      </div>

      {/* ─── LIVE CTA ─── */}
      <section className="py-24 bg-radial-ember">
        <div className="mx-auto max-w-3xl px-4 text-center sm:px-6 lg:px-8">
          <RevealSection>
            <div className="mb-5 flex justify-center">
              <div className="flex h-16 w-16 items-center justify-center rounded-3xl border border-ember-400/30 bg-ember-400/10 text-ember-400">
                <Radio className="h-7 w-7" />
              </div>
            </div>
            <h2 className="font-serif text-4xl font-semibold text-cream">Suivez-nous en direct</h2>
            <p className="mt-4 text-muted">
              Rejoignez notre diffusion en direct chaque dimanche et lors de nos événements spéciaux.
            </p>
            <button onClick={() => onNavigate('events')} className="btn-ember mt-8">
              <Radio className="h-4 w-4" />
              Suivre le Direct
            </button>
          </RevealSection>
        </div>
      </section>

      <SiteFooter onNavigate={onNavigate} theme={theme} onToggleTheme={onToggleTheme} />
      <MobileNav onNavigate={onNavigate} active="media" theme={theme} onToggleTheme={onToggleTheme} />
    </div>
  );
}
