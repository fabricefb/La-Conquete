import { useReveal } from '../lib/hooks';
import { SiteHeader } from '../components/SiteHeader';
import { SiteFooter } from '../components/SiteFooter';
import { MobileNav } from '../components/MobileNav';
import { Crown, Flame, Compass, Heart, BookOpen, Users, Quote } from '../lib/icons';
import type { Page } from '../lib/navigation';
import type { Theme } from '../lib/theme';

const CHURCH = 'https://images.pexels.com/photos/290468/pexels-photo-290468.jpeg?auto=compress&cs=tinysrgb&w=1200';
const PEOPLE = 'https://images.pexels.com/photos/8465180/pexels-photo-8465180.jpeg?auto=compress&cs=tinysrgb&w=800';

interface AboutPageProps { onNavigate: (page: Page) => void; theme: Theme; onToggleTheme: () => void; }

const values = [
  { label: 'Bâtir', desc: 'Des fondations solides ancrées dans la Parole de Dieu et la prière.', Icon: Crown, accent: 'text-gold-400', radial: 'bg-radial-gold' },
  { label: 'Transformer', desc: 'Permettre à chacun de vivre une transformation intérieure profonde.', Icon: Flame, accent: 'text-ember-400', radial: 'bg-radial-ember' },
  { label: 'Conquérir', desc: 'Avancer avec audace dans notre mission divine pour impacter les nations.', Icon: Compass, accent: 'text-gold-400', radial: 'bg-radial-gold' },
  { label: 'Aimer', desc: "Manifester l'amour de Dieu dans chaque aspect de notre communauté.", Icon: Heart, accent: 'text-ember-400', radial: 'bg-radial-ember' },
];

const beliefs = [
  { title: 'La Bible', desc: 'La Sainte Bible est la Parole inspirée de Dieu, notre autorité suprême en matière de foi et de conduite.', Icon: BookOpen },
  { title: 'La Trinité', desc: 'Nous croyons en un seul Dieu, éternellement existant en trois personnes : le Père, le Fils et le Saint-Esprit.', Icon: Crown },
  { title: 'Le Salut', desc: 'Le salut est un don de la grâce de Dieu, reçu par la foi en Jésus-Christ et sa mort expiatoire sur la croix.', Icon: Heart },
  { title: "L'Église", desc: "L'Église est le Corps de Christ, une communauté de croyants appelés à adorer Dieu et à proclamer l'Évangile.", Icon: Users },
];

const team = [
  { name: 'Jacques-Daniel Kongolo', role: 'Pasteur Principal', desc: "Visionnaire et serviteur, le Pasteur Kongolo dirige La Conquête depuis sa fondation avec une passion pour l'évangélisation et la formation des disciples." },
  { name: 'Josué Romain Kazadi', role: 'Pasteur Associé', desc: 'Avec un cœur pour la jeunesse et les missions, le Pasteur Kazadi accompagne la vision de l'église et développe les ministères de formation.' },
];

function RevealSection({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  const { ref, visible } = useReveal();
  return <div ref={ref} className={`reveal ${visible ? 'in' : ''} ${className}`}>{children}</div>;
}

export function AboutPage({ onNavigate, theme, onToggleTheme }: AboutPageProps) {
  return (
    <div className="min-h-screen bg-bg text-cream">
      <SiteHeader onNavigate={onNavigate} activePage="about" theme={theme} onToggleTheme={onToggleTheme} />

      {/* ─── HERO ─── */}
      <section className="relative flex min-h-[50vh] items-center justify-center overflow-hidden pt-16 bg-radial-gold">
        <div className="relative z-10 mx-auto max-w-3xl px-4 py-24 text-center">
          <RevealSection>
            <p className="section-label justify-center">Notre identité</p>
            <h1 className="mt-4 font-serif text-5xl font-semibold text-cream sm:text-6xl">Qui sommes-nous&nbsp;?</h1>
            <p className="mt-6 text-lg text-muted">
              Une église de foi, d'espérance et d'amour, enracinée dans la Parole de Dieu et tournée vers l'avenir.
            </p>
          </RevealSection>
        </div>
      </section>

      {/* ─── VISION SPLIT ─── */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid items-center gap-16 lg:grid-cols-2">
            <RevealSection>
              <div className="overflow-hidden rounded-5xl">
                <img src={CHURCH} alt="Église La Conquête" className="h-[480px] w-full object-cover transition-transform duration-700 hover:scale-105" />
              </div>
            </RevealSection>
            <RevealSection className="reveal-delay-1">
              <p className="section-label">Notre histoire</p>
              <h2 className="mt-4 font-serif text-4xl font-semibold text-cream leading-snug">
                L'histoire de<br />La Conquête
              </h2>
              <p className="mt-6 text-muted leading-relaxed">
                Née d'une vision divine, l'Église La Conquête a été fondée avec la conviction profonde que chaque vie peut être transformée par la puissance de l'Évangile. Depuis ses débuts modestes, elle est devenue une communauté vibrante qui impacte des milliers de vies.
              </p>
              <p className="mt-4 text-muted leading-relaxed">
                Ancrée dans la Parole de Dieu et portée par le souffle du Saint-Esprit, La Conquête avance chaque jour avec la foi que Dieu réalise ses promesses à travers ses enfants fidèles.
              </p>
              <blockquote className="mt-8 border-l-2 border-gold-400/40 pl-5 text-sm italic text-muted">
                « Demande-moi, et je te donnerai les nations pour héritage, et les extrémités de la terre pour ta possession. »
                <span className="mt-1 block not-italic font-semibold text-gold-400">— Psaumes 2:8</span>
              </blockquote>
            </RevealSection>
          </div>
        </div>
      </section>

      {/* ─── VALUES ─── */}
      <section className="py-24 bg-radial-gold">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <RevealSection className="mb-14 text-center">
            <p className="section-label justify-center">Ce qui nous anime</p>
            <h2 className="mt-4 font-serif text-4xl font-semibold text-cream">Nos valeurs</h2>
          </RevealSection>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {values.map(({ label, desc, Icon, accent, radial }, i) => (
              <RevealSection key={label} className={`reveal-delay-${i + 1}`}>
                <div className={`glass rounded-3xl p-7 ${radial} h-full transition-all duration-300 hover:scale-105`}>
                  <div className={`mb-4 inline-flex h-11 w-11 items-center justify-center rounded-2xl border border-line ${accent}`}>
                    <Icon className="h-5 w-5" />
                  </div>
                  <h3 className={`mb-2 font-serif text-xl font-semibold ${accent}`}>{label}</h3>
                  <p className="text-sm text-muted leading-relaxed">{desc}</p>
                </div>
              </RevealSection>
            ))}
          </div>
        </div>
      </section>

      {/* ─── BELIEFS ─── */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <RevealSection className="mb-14 text-center">
            <p className="section-label justify-center">Notre foi</p>
            <h2 className="mt-4 font-serif text-4xl font-semibold text-cream">Ce que nous croyons</h2>
          </RevealSection>
          <div className="grid gap-6 sm:grid-cols-2">
            {beliefs.map(({ title, desc, Icon }, i) => (
              <RevealSection key={title} className={`reveal-delay-${(i % 2) + 1}`}>
                <div className="glass rounded-3xl p-8 flex gap-5 h-full transition-all duration-300 hover:scale-[1.02]">
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl border border-gold-400/20 text-gold-400 mt-0.5">
                    <Icon className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="mb-2 font-serif text-xl font-semibold text-cream">{title}</h3>
                    <p className="text-sm text-muted leading-relaxed">{desc}</p>
                  </div>
                </div>
              </RevealSection>
            ))}
          </div>
        </div>
      </section>

      {/* ─── TEAM ─── */}
      <section className="py-24 bg-radial-gold">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <RevealSection className="mb-14 text-center">
            <p className="section-label justify-center">Leadership</p>
            <h2 className="mt-4 font-serif text-4xl font-semibold text-cream">Notre équipe pastorale</h2>
          </RevealSection>
          <div className="grid gap-8 sm:grid-cols-2 max-w-3xl mx-auto">
            {team.map(({ name, role, desc }, i) => (
              <RevealSection key={name} className={`reveal-delay-${i + 1}`}>
                <div className="glass rounded-3xl overflow-hidden transition-all duration-300 hover:scale-105">
                  <div className="h-64 overflow-hidden">
                    <img src={PEOPLE} alt={name} className="h-full w-full object-cover object-top transition-transform duration-700 hover:scale-110" />
                  </div>
                  <div className="p-6">
                    <h3 className="font-serif text-xl font-semibold text-cream">{name}</h3>
                    <p className="mt-1 text-xs font-semibold uppercase tracking-widest text-gold-400">{role}</p>
                    <p className="mt-3 text-sm text-muted leading-relaxed">{desc}</p>
                  </div>
                </div>
              </RevealSection>
            ))}
          </div>
        </div>
      </section>

      {/* ─── QUOTE ─── */}
      <section className="py-24">
        <div className="mx-auto max-w-3xl px-4 text-center sm:px-6 lg:px-8">
          <RevealSection>
            <div className="glass rounded-4xl p-12">
              <Quote className="mx-auto mb-6 h-10 w-10 text-gold-400/50" />
              <p className="font-serif text-xl italic leading-relaxed text-cream sm:text-2xl">
                « Notre appel est de construire des hommes et des femmes de Dieu qui, à leur tour, transforment le monde qui les entoure. »
              </p>
              <p className="mt-6 font-semibold text-gold-400">— Pasteur Jacques-Daniel Kongolo</p>
            </div>
          </RevealSection>
        </div>
      </section>

      <SiteFooter onNavigate={onNavigate} theme={theme} onToggleTheme={onToggleTheme} />
      <MobileNav onNavigate={onNavigate} active="about" theme={theme} onToggleTheme={onToggleTheme} />
    </div>
  );
}
